Datos RAW extraídos de Kaggle.
